"""
Leaf venation (Runions et al., SIGGRAPH 2005) for Blender Geometry Nodes.

Run this file once in Blender's Scripting workspace (Text Editor > Open > Run Script).
Tested in Blender 4.2 LTS and 5.0. It creates:

  * "Leaf Venation"          node group. Space colonization grown inside a
                             Geometry Nodes Repeat Zone (open venation), plus
                             vein tubes with Murray's-law widths and a leaf blade.
                             Put it as a modifier on a closed curve (the leaf
                             outline, drawn on the XY plane).
  * "Leaf Venation Skin"     node group. Only the tubes + blade, for a vein mesh
                             made by the Python simulator (closed / looped
                             patterns and isogonic growth, which Geometry Nodes
                             can't do well).
  * a demo scene with the six presets of GRASSHOPPER_GUIDE.md.

Functions you can call from the Python console after running it:

  build_node_groups()                      (re)create the node groups
  make_outline(name, kind="ovate", **kw)   leaf outline curve object
  add_leaf_nodes(preset_number)            Geometry Nodes leaf  (presets 1, 2, 5, 6)
  add_leaf_python(preset_number)           Python-simulated leaf (all presets, incl. 3, 4)
  bake_texture(obj, path, size=2048)       PNG vein texture, wired into the blade material
  build_demo()                             all six presets side by side

Units follow the Grasshopper presets: a leaf is about 100 units long. The demo
objects are scaled by 0.01 so each leaf is 1 m in the viewport.
"""

import math
import random

import bpy

# ---------------------------------------------------------------------------
# Venation core, copied unchanged from leaf_venation_ghpython.py
# ---------------------------------------------------------------------------

class Grid(object):
    """Uniform grid spatial hash for 2D points keyed by integer id."""

    def __init__(self, cell):
        self.cell = float(cell)
        self.cells = {}
        self.pos = {}

    def _key(self, x, y):
        return (int(math.floor(x / self.cell)), int(math.floor(y / self.cell)))

    def add(self, i, x, y):
        self.pos[i] = (x, y)
        self.cells.setdefault(self._key(x, y), []).append(i)

    def remove(self, i):
        x, y = self.pos.pop(i)
        lst = self.cells[self._key(x, y)]
        lst.remove(i)
        if not lst:
            del self.cells[self._key(x, y)]

    def __len__(self):
        return len(self.pos)

    def within(self, x, y, r):
        """Ids within distance r of (x, y)."""
        out = []
        r2 = r * r
        cx0, cy0 = self._key(x - r, y - r)
        cx1, cy1 = self._key(x + r, y + r)
        cells = self.cells
        pos = self.pos
        for cx in range(cx0, cx1 + 1):
            for cy in range(cy0, cy1 + 1):
                lst = cells.get((cx, cy))
                if lst:
                    for i in lst:
                        px, py = pos[i]
                        if (px - x) ** 2 + (py - y) ** 2 < r2:
                            out.append(i)
        return out

    def nearest(self, x, y, maxr=None):
        """(id, distance) of the nearest point, or (None, inf)."""
        if not self.pos:
            return None, float("inf")
        kx, ky = self._key(x, y)
        best, bd2 = None, float("inf")
        ring = 0
        cells = self.cells
        pos = self.pos
        # upper bound on rings so an empty far region terminates
        limit = 1 + int(1e6)
        while ring < limit:
            for cx in range(kx - ring, kx + ring + 1):
                for cy in (range(ky - ring, ky + ring + 1)
                           if cx in (kx - ring, kx + ring)
                           else (ky - ring, ky + ring)):
                    lst = cells.get((cx, cy))
                    if lst:
                        for i in lst:
                            px, py = pos[i]
                            d2 = (px - x) ** 2 + (py - y) ** 2
                            if d2 < bd2:
                                bd2, best = d2, i
            # every unvisited cell is at least ring*cell away
            reach = ring * self.cell
            if best is not None and reach * reach >= bd2:
                break
            if maxr is not None and reach > maxr:
                break
            if ring > 0 and reach > 4 * self._extent():
                break
            ring += 1
        return best, math.sqrt(bd2)

    def _extent(self):
        if not hasattr(self, "_ext_cache") or self._ext_n != len(self.pos):
            xs = [p[0] for p in self.pos.values()]
            ys = [p[1] for p in self.pos.values()]
            self._ext_cache = max(max(xs) - min(xs), max(ys) - min(ys), self.cell)
            self._ext_n = len(self.pos)
        return self._ext_cache


def point_in_polygon(x, y, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            if x < (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi:
                inside = not inside
        j = i
    return inside


def polygon_area(poly):
    a = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        a += x0 * y1 - x1 * y0
    return abs(a) * 0.5


class Venation(object):
    """Space colonization venation, open and closed variants."""

    def __init__(self, polygon, seeds, base=None, D=1.0, kill=2.5,
                 birth_s=3.0, birth_v=3.0, darts=40, growth=1,
                 start_scale=0.15, iterations=150, closed=False,
                 seed=1, inside_only=True, grow_steps=0):
        self.final_poly = [tuple(p) for p in polygon]
        self.base = tuple(base) if base else tuple(seeds[0])
        self.D = float(D)
        self.kill = float(kill)
        self.bs = float(birth_s)
        self.bv = float(birth_v)
        self.darts = int(darts)
        self.growth = int(growth)
        self.closed = bool(closed)
        self.inside_only = inside_only
        self.iterations = int(iterations)
        self.rng = random.Random(seed)

        self.sigma = 1.0 if self.growth == 0 else float(start_scale)
        # by default reach full size at ~70% of the run, then keep filling
        steps_to_full = int(grow_steps) or int(self.iterations * 0.7)
        steps_to_full = max(1, steps_to_full)
        self.dsigma = (1.0 - self.sigma) / steps_to_full

        cell = max(self.D, self.kill, 1e-6)
        self.nodes = Grid(cell)
        self.sources = Grid(max(self.bs, 1e-6))
        self.parent = []        # parent id per node (-1 for roots)
        self.children = []      # child ids per node
        self.extra = []         # loop edges (a, b) created by anastomoses
        self.node_xy = []
        self.src_state = {}     # closed mode bookkeeping per source
        self._next_src = 0

        if self.growth == 2:
            # uniform growth: everything lives in a frame that is scaled up
            seeds = [self._scale_pt(p, self.sigma) for p in seeds]
        for p in seeds:
            self._add_node(p[0], p[1], -1)

        # Marginal growth (paper Sec. 3.3): the source field is precomputed
        # over the full-size leaf and each source switches on when the
        # expanding margin passes it.
        self.pending = []
        if self.growth in (1, 3):
            self._precompute_sources()

    # -- geometry helpers --------------------------------------------------
    def _scale_pt(self, p, s):
        bx, by = self.base
        sx = 1.0 if self.growth == 3 else s   # mode 3: grows in length only
        return (bx + (p[0] - bx) * sx, by + (p[1] - by) * s)

    def current_poly(self):
        return [self._scale_pt(p, self.sigma) for p in self.final_poly]

    def _add_node(self, x, y, parent):
        i = len(self.node_xy)
        self.node_xy.append((x, y))
        self.parent.append(parent)
        self.children.append([])
        if parent >= 0:
            self.children[parent].append(i)
        self.nodes.add(i, x, y)
        return i

    def _rebuild_grids(self, factor):
        bx, by = self.base
        new_nodes = Grid(self.nodes.cell)
        for i, (x, y) in enumerate(self.node_xy):
            p = (bx + (x - bx) * factor, by + (y - by) * factor)
            self.node_xy[i] = p
            new_nodes.add(i, p[0], p[1])
        self.nodes = new_nodes
        new_src = Grid(self.sources.cell)
        for i, (x, y) in self.sources.pos.items():
            new_src.add(i, bx + (x - bx) * factor, by + (y - by) * factor)
        self.sources = new_src

    # -- the three processes -----------------------------------------------
    def grow_leaf(self):
        if self.growth == 0 or self.sigma >= 1.0:
            return
        new_sigma = min(1.0, self.sigma + self.dsigma)
        if self.growth == 2:
            self._rebuild_grids(new_sigma / self.sigma)
        self.sigma = new_sigma

    def _entry_scale(self, x, y):
        """Smallest leaf scale at which (x, y) lies inside the margin."""
        bx, by = self.base
        if self.growth == 3:
            ox, oy, dx, dy = x, by, 0.0, y - by
        else:
            ox, oy, dx, dy = bx, by, x - bx, y - by
        if abs(dx) + abs(dy) < 1e-12:
            return 0.0
        tmax = 0.0
        poly = self.final_poly
        n = len(poly)
        for i in range(n):
            ax, ay = poly[i]
            cx, cy = poly[(i + 1) % n]
            ex, ey = cx - ax, cy - ay
            den = dx * ey - dy * ex
            if abs(den) < 1e-15:
                continue
            t = ((ax - ox) * ey - (ay - oy) * ex) / den
            u = ((ax - ox) * dy - (ay - oy) * dx) / den
            if 0.0 <= u <= 1.0 and t > tmax:
                tmax = t
        return 1.0 / tmax if tmax > 0 else 2.0

    def _precompute_sources(self):
        poly = self.final_poly
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        area = polygon_area(poly)
        cap = int(30 * area / (self.bs * self.bs)) + 100
        tries = min(self.darts * self.iterations, cap)
        field = Grid(self.bs)
        rnd = self.rng.random
        out = []
        for _ in range(tries):
            x = x0 + (x1 - x0) * rnd()
            y = y0 + (y1 - y0) * rnd()
            if field.within(x, y, self.bs):
                continue
            if not point_in_polygon(x, y, poly):
                continue
            field.add(len(out), x, y)
            out.append((self._entry_scale(x, y), x, y))
        out.sort(reverse=True)  # pop() from the end = smallest entry scale
        self.pending = out

    def place_sources(self, poly):
        if self.growth in (1, 3):
            added = 0
            while self.pending and self.pending[-1][0] <= self.sigma + 1e-9:
                _, x, y = self.pending.pop()
                if self.nodes.within(x, y, self.bv):
                    continue
                sid = self._next_src
                self._next_src += 1
                self.sources.add(sid, x, y)
                added += 1
            return added
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        rnd = self.rng.random
        added = 0
        for _ in range(self.darts):
            x = x0 + (x1 - x0) * rnd()
            y = y0 + (y1 - y0) * rnd()
            if not point_in_polygon(x, y, poly):
                continue
            if self.sources.within(x, y, self.bs):
                continue
            if self.nodes.within(x, y, self.bv):
                continue
            sid = self._next_src
            self._next_src += 1
            self.sources.add(sid, x, y)
            added += 1
        return added

    def relative_neighbors(self, sx, sy):
        """Vein nodes in the relative neighbourhood of a source (Eq. 2)."""
        nid, d0 = self.nodes.nearest(sx, sy)
        if nid is None:
            return []
        radius = d0 + self.bs  # local search window, cf. Urquhart approx.
        cand = self.nodes.within(sx, sy, radius + 1e-9)
        pos = self.nodes.pos
        cand.sort(key=lambda i: (pos[i][0] - sx) ** 2 + (pos[i][1] - sy) ** 2)
        result = []
        dists = [math.hypot(pos[i][0] - sx, pos[i][1] - sy) for i in cand]
        for a, v in enumerate(cand):
            vx, vy = pos[v]
            dv = dists[a]
            ok = True
            for b in range(a):
                u = cand[b]
                if dists[b] >= dv:
                    break
                ux, uy = pos[u]
                if math.hypot(ux - vx, uy - vy) < dv:
                    ok = False
                    break
            if ok:
                result.append(v)
        return result

    def associate(self):
        """Return {node_id: [source_ids]} (S(v) in the paper)."""
        influence = {}
        if self.closed:
            self._rn_cache = {}
            for sid, (sx, sy) in self.sources.pos.items():
                rn = self.relative_neighbors(sx, sy)
                self._rn_cache[sid] = rn
                for v in rn:
                    influence.setdefault(v, []).append(sid)
        else:
            for sid, (sx, sy) in self.sources.pos.items():
                v, _ = self.nodes.nearest(sx, sy)
                if v is not None:
                    influence.setdefault(v, []).append(sid)
        return influence

    def add_veins(self, influence, poly):
        new_nodes = []
        spos = self.sources.pos
        D = self.D
        for v, srcs in influence.items():
            vx, vy = self.node_xy[v]
            nx = ny = 0.0
            for s in srcs:
                sx, sy = spos[s]
                dx, dy = sx - vx, sy - vy
                L = math.hypot(dx, dy)
                if L > 1e-12:
                    nx += dx / L
                    ny += dy / L
            L = math.hypot(nx, ny)
            if L < 1e-9:
                continue
            px, py = vx + D * nx / L, vy + D * ny / L
            if self.inside_only and not point_in_polygon(px, py, poly):
                continue
            # do not stack nodes on top of each other (stalled tips)
            if self.nodes.within(px, py, D * 0.2):
                continue
            new_nodes.append((v, px, py, srcs))
        created = []
        for v, px, py, srcs in new_nodes:
            nid = self._add_node(px, py, v)
            created.append((nid, v, srcs))
        return created

    def kill_sources(self, created):
        if not self.closed:
            dead = set()
            for nid, _, _ in created:
                x, y = self.node_xy[nid]
                for s in self.sources.within(x, y, self.kill):
                    dead.add(s)
            for s in dead:
                self.sources.remove(s)
            return len(dead)
        return self._kill_closed(created)

    def _kill_closed(self, created):
        # pass tags from tagged nodes to the children that grew toward s
        grew_from = {}
        heading = set()
        for nid, v, srcs in created:
            for s in srcs:
                grew_from[(v, s)] = nid
                heading.add((nid, s))
        dead = []
        rn_cache = getattr(self, "_rn_cache", {})
        for sid, (sx, sy) in list(self.sources.pos.items()):
            st = self.src_state.get(sid)
            if st is None:
                near = self.nodes.within(sx, sy, self.kill)
                if not near:
                    continue
                # first vein reached: tag every vein heading for this source
                tagged = set(rn_cache.get(sid, []))
                for nid, v, srcs in created:
                    if sid in srcs:
                        tagged.discard(v)
                        tagged.add(nid)
                st = {"tagged": tagged, "age": 0}
                self.src_state[sid] = st
            else:
                new_tags = set()
                for t in st["tagged"]:
                    new_tags.add(grew_from.get((t, sid), t))
                st["tagged"] = new_tags
                st["age"] += 1
            # a tagged vein is finished when it reached s or stopped growing
            # toward it (left its zone of influence)
            pending = []
            for t in st["tagged"]:
                tx, ty = self.node_xy[t]
                reached = math.hypot(tx - sx, ty - sy) < self.kill
                still_heading = (t, sid) in heading
                if not reached and still_heading:
                    pending.append(t)
            if not pending or st["age"] > 3 * self.kill / self.D + 5:
                dead.append((sid, sx, sy, st["tagged"]))
        for sid, sx, sy, tagged in dead:
            self.sources.remove(sid)
            self.src_state.pop(sid, None)
            # close the loop: join every tip that arrived at this source
            tips = [t for t in tagged
                    if math.hypot(self.node_xy[t][0] - sx,
                                  self.node_xy[t][1] - sy) < self.kill * 1.01]
            if len(tips) >= 2:
                tips.sort()
                hub = tips[0]
                for t in tips[1:]:
                    if t != hub and self.parent[t] != hub:
                        self.extra.append((hub, t))
        return len(dead)

    def step(self):
        self.grow_leaf()
        poly = self.current_poly()
        self.place_sources(poly)
        influence = self.associate()
        created = self.add_veins(influence, poly)
        self.kill_sources(created)
        return len(created)

    def run(self, max_nodes=200000):
        for it in range(self.iterations):
            n = self.step()
            if len(self.node_xy) > max_nodes:
                break
            if n == 0 and self.sigma >= 1.0 and len(self.sources) == 0:
                # leaf full and no live sources: try a few more darts
                if self.place_sources(self.current_poly()) == 0:
                    break
        return self

    # -- results -------------------------------------------------------------
    def radii(self, murray_n=2.5, r_min=0.05):
        """Murray's law: r_parent^n = sum r_child^n, from veinlets to base."""
        n = float(murray_n)
        r = [r_min] * len(self.node_xy)
        acc = [0.0] * len(self.node_xy)
        loop_in = {}
        for a, b in self.extra:  # loops: both ends feed equally
            loop_in[a] = loop_in.get(a, 0) + 1
        for i in range(len(self.node_xy) - 1, -1, -1):
            if self.children[i]:
                r[i] = max(r_min, acc[i] ** (1.0 / n))
            p = self.parent[i]
            if p >= 0:
                acc[p] += r[i] ** n
        return r

    def branches(self):
        """Chains of node ids between branch points (one polyline each)."""
        out = []
        starts = [i for i, p in enumerate(self.parent) if p < 0]
        stack = list(starts)
        while stack:
            s = stack.pop()
            kids = self.children[s]
            for k in kids:
                chain = [s, k]
                cur = k
                while len(self.children[cur]) == 1:
                    cur = self.children[cur][0]
                    chain.append(cur)
                out.append(chain)
                if self.children[cur]:
                    stack.append(cur)
        for a, b in self.extra:
            out.append([a, b])
        return out

    def edges(self):
        e = [(p, i) for i, p in enumerate(self.parent) if p >= 0]
        return e + list(self.extra)


# ---------------------------------------------------------------------------
# Small helpers to build node trees from Python
# ---------------------------------------------------------------------------

def _enabled(sockets):
    return [s for s in sockets if getattr(s, "enabled", True)]


def _find(sockets, key):
    socks = _enabled(sockets)
    if isinstance(key, int):
        return socks[key]
    for s in socks:
        if s.name == key or s.identifier == key:
            return s
    for s in sockets:   # fall back to disabled sockets with that name
        if s.name == key or s.identifier == key:
            return s
    raise KeyError("%s has no socket %r (has %s)" % (
        sockets[0].node.bl_idname if len(sockets) else "?", key,
        [s.name for s in socks]))


class NB(object):
    """Tiny node-tree builder: nb.n(idname, {input: value_or_socket}, prop=...)."""

    def __init__(self, tree):
        self.t = tree
        self.count = 0

    def out(self, x, key=0):
        if isinstance(x, bpy.types.NodeSocket):
            return x
        if isinstance(x, tuple):
            return _find(x[0].outputs, x[1])
        return _find(x.outputs, key)

    def link(self, value, sock):
        if isinstance(value, (bpy.types.NodeSocket, bpy.types.Node)) or (
                isinstance(value, tuple) and value
                and isinstance(value[0], bpy.types.Node)):
            self.t.links.new(self.out(value), sock)
        else:
            sock.default_value = value

    def n(self, idname, inputs=None, **props):
        node = self.t.nodes.new(idname)
        node.location = ((self.count % 12) * 220, -(self.count // 12) * 260)
        self.count += 1
        for k, v in props.items():
            if hasattr(node, k):
                setattr(node, k, v)
            else:   # Blender 5 turned some enums into menu sockets
                _find(node.inputs, k).default_value = v
        for k, v in (inputs or {}).items():
            if v is not None:
                self.link(v, _find(node.inputs, k))
        return node

    # shorthands returning output sockets
    def math(self, op, a, b=0.0, c=0.0):
        node = self.n("ShaderNodeMath", operation=op)
        for sock, v in zip(_enabled(node.inputs), (a, b, c)):
            self.link(v, sock)
        return self.out(node)

    def vec(self, x=0.0, y=0.0, z=0.0):
        """Constant vector as a node (field inputs ignore default values)."""
        return self.out(self.n("ShaderNodeCombineXYZ", {"X": x, "Y": y, "Z": z}))

    def vmath(self, op, a, b=None, scale=None):
        node = self.n("ShaderNodeVectorMath", operation=op)
        self.link(a, _find(node.inputs, 0))
        if b is not None:
            self.link(b, _find(node.inputs, 1))
        if scale is not None:
            self.link(scale, _find(node.inputs, "Scale"))
        return self.out(node, "Value" if op in ("LENGTH", "DOT_PRODUCT",
                                                "DISTANCE") else "Vector")

    def cmp(self, op, a, b, dtype="FLOAT"):
        return self.out(self.n("FunctionNodeCompare", {0: a, 1: b},
                               data_type=dtype, operation=op))

    def boolean(self, op, a, b=None):
        node = self.n("FunctionNodeBooleanMath", operation=op)
        self.link(a, _find(node.inputs, 0))
        if b is not None:
            self.link(b, _find(node.inputs, 1))
        return self.out(node)

    def attr(self, name, dtype="FLOAT"):
        return self.out(self.n("GeometryNodeInputNamedAttribute",
                               {"Name": name}, data_type=dtype), "Attribute")

    def store(self, geo, name, value, dtype="FLOAT", domain="POINT"):
        return self.out(self.n("GeometryNodeStoreNamedAttribute",
                               {"Geometry": geo, "Name": name, "Value": value},
                               data_type=dtype, domain=domain))

    def mixv(self, fac, a, b):
        """a * (1 - fac) + b * fac for vectors."""
        node = self.n("ShaderNodeMix", data_type="VECTOR")
        self.link(fac, _find(node.inputs, "Factor"))
        self.link(a, _find(node.inputs, "A"))
        self.link(b, _find(node.inputs, "B"))
        return self.out(node, "Result")

    def switch(self, cond, false, true, itype="GEOMETRY"):
        return self.out(self.n("GeometryNodeSwitch",
                               {"Switch": cond, "False": false, "True": true},
                               input_type=itype))

    def delete(self, geo, sel, domain="POINT", mode="ALL"):
        return self.out(self.n("GeometryNodeDeleteGeometry",
                               {"Geometry": geo, "Selection": sel},
                               domain=domain, mode=mode))

    def sample_index(self, geo, value, index, dtype="FLOAT"):
        return self.out(self.n("GeometryNodeSampleIndex",
                               {"Geometry": geo, "Value": value,
                                "Index": index}, data_type=dtype,
                               domain="POINT"))

    def proximity(self, target, pos):
        node = self.n("GeometryNodeProximity", target_element="POINTS")
        self.link(target, node.inputs[0])
        self.link(pos, _find(node.inputs, "Source Position"))
        return self.out(node, "Distance")

    def join(self, *geos):
        node = self.n("GeometryNodeJoinGeometry")
        for g in reversed(geos):   # multi-input sockets stack in reverse
            self.t.links.new(self.out(g), node.inputs[0])
        return self.out(node)


def _new_tree(name):
    old = bpy.data.node_groups.get(name)
    if old is not None:
        bpy.data.node_groups.remove(old)
    tree = bpy.data.node_groups.new(name, "GeometryNodeTree")
    return tree


def _sock(tree, name, stype, in_out="INPUT", default=None, lo=None, hi=None,
          desc=""):
    item = tree.interface.new_socket(name, in_out=in_out,
                                     socket_type="NodeSocket" + stype)
    item.description = desc
    if default is not None:
        item.default_value = default
    if lo is not None:
        item.min_value = lo
    if hi is not None:
        item.max_value = hi
    return item


def _io(tree):
    gi = tree.nodes.new("NodeGroupInput")
    go = tree.nodes.new("NodeGroupOutput")
    gi.location = (-400, 0)
    go.location = (3000, 0)
    return gi, go


# ---------------------------------------------------------------------------
# Node group 1: grow the veins (space colonization in a Repeat Zone)
# ---------------------------------------------------------------------------

GROW_INPUTS = [
    # name, type, default, min, max, description
    ("Base", "Vector", (0.0, 0.0, 0.0), None, None,
     "Petiole point: first vein node and growth centre"),
    ("Seed Count", "Int", 1, 1, 64,
     "Number of starting vein nodes spread along X (grass: 6)"),
    ("Seed Spacing", "Float", 4.0, 0.0, None, "Distance between seeds"),
    ("Iterations", "Int", 220, 0, 5000, "Simulation steps"),
    ("Segment Length", "Float", 1.0, 0.001, None, "D: length of a new vein segment"),
    ("Kill Distance", "Float", 4.0, 0.001, None,
     "dk: a source dies when a vein comes this close"),
    ("Source Spacing", "Float", 4.0, 0.001, None,
     "bs: minimum distance between auxin sources"),
    ("Vein Birth Distance", "Float", 4.0, 0.0, None,
     "bv: a source that switches on this close to a vein is dropped"),
    ("Source Density", "Float", 1.0, 0.0, None,
     "Poisson candidates per unit area. Higher = more regular source field "
     "(the paper's dart count)"),
    ("Growth", "Int", 1, 0, 3,
     "0 static leaf, 1 marginal growth, 3 length-only growth (grass). "
     "2 (isogonic) is only in the Python simulator and acts like 1 here"),
    ("Start Scale", "Float", 0.1, 0.001, 1.0, "Leaf size at step 0"),
    ("Growth Steps", "Int", 0, 0, 5000,
     "Steps to reach full size, 0 = 70% of Iterations. Larger = slower growth"),
    ("Random Seed", "Int", 0, None, None, "Seed for the source field"),
]


def _grow_loop(t, nb, G, go, seeds, sources, snap=None):
    """Space colonization Repeat Zone shared by the flat and surface groups.
    seeds: vein mesh with 'age'/'root'; sources: points with 'lv_entry'."""
    pos = nb.out(nb.n("GeometryNodeInputPosition"))
    index = nb.out(nb.n("GeometryNodeInputIndex"))
    D = G("Segment Length")
    growth = G("Growth")
    # -- growth schedule constants --------------------------------------------
    auto_steps = nb.math("MAXIMUM", nb.math("FLOOR", nb.math(
        "MULTIPLY", G("Iterations"), 0.7)), 1.0)
    use_auto = nb.cmp("LESS_THAN", G("Growth Steps"), 0.5)
    steps_full = nb.math("ADD", nb.math("MAXIMUM", G("Growth Steps"), 0.0),
                         nb.math("MULTIPLY", use_auto, auto_steps))
    static = nb.cmp("LESS_THAN", growth, 0.5)
    s0 = G("Start Scale")

    # -- the Repeat Zone -------------------------------------------------------
    rin = t.nodes.new("GeometryNodeRepeatInput")
    rout = t.nodes.new("GeometryNodeRepeatOutput")
    rin.pair_with_output(rout)
    rout.repeat_items.new("GEOMETRY", "Sources")
    rout.repeat_items.new("INT", "Step")
    rin.location = (0, -900)
    rout.location = (2600, -900)
    nb.link(G("Iterations"), _find(rin.inputs, "Iterations"))
    nb.link(seeds, _find(rin.inputs, "Geometry"))
    nb.link(sources, _find(rin.inputs, "Sources"))
    _find(rin.inputs, "Step").default_value = 0

    V = _find(rin.outputs, "Geometry")
    S = _find(rin.outputs, "Sources")
    step = _find(rin.outputs, "Step")
    step1 = nb.math("ADD", step, 1.0)

    # leaf scale this step (leaf grows first, then sources switch on)
    sigma = nb.math("MINIMUM", nb.math("ADD", s0, nb.math(
        "DIVIDE", nb.math("MULTIPLY", nb.math("SUBTRACT", 1.0, s0), step1),
        steps_full)), 1.0)
    sigma = nb.math("ADD", sigma, nb.math("MULTIPLY", static, 10.0))
    active = nb.cmp("LESS_EQUAL", nb.attr("lv_entry"), sigma)
    sep = nb.n("GeometryNodeSeparateGeometry",
               {"Geometry": S, "Selection": active}, domain="POINT")
    A = nb.out(sep, "Selection")
    I = nb.out(sep, "Inverted")

    # each active source picks its closest vein node ...
    target = nb.out(nb.n("GeometryNodeSampleNearest",
                         {"Geometry": V, "Sample Position": pos},
                         domain="POINT"))
    tpos = nb.sample_index(V, pos, target, "FLOAT_VECTOR")
    tage = nb.sample_index(V, nb.attr("age"), target)
    troot = nb.sample_index(V, nb.attr("root"), target)
    toward = nb.vmath("NORMALIZE", nb.vmath("SUBTRACT", pos, tpos))
    # ... and each node sums the unit vectors of its sources (Eq. 1)
    acc = nb.n("GeometryNodeAccumulateField",
               {"Value": toward, "Group ID": target},
               data_type="FLOAT_VECTOR", domain="POINT")
    lead = nb.n("GeometryNodeAccumulateField",
                {"Value": 1, "Group ID": target}, data_type="INT",
                domain="POINT")
    newpos = nb.vmath("ADD", tpos, nb.vmath(
        "SCALE", nb.vmath("NORMALIZE", nb.out(acc, "Total")), scale=D))
    if snap is not None:   # keep new nodes on the object's surface
        newpos = snap(newpos)
    A2 = nb.store(A, "lv_t", tpos, "FLOAT_VECTOR")
    A2 = nb.store(A2, "lv_n", newpos, "FLOAT_VECTOR")
    A2 = nb.store(A2, "lv_a", tage)
    A2 = nb.store(A2, "lv_r", troot)
    # one representative source per growing node
    reps = nb.delete(A2, nb.cmp("NOT_EQUAL", nb.out(lead, "Leading"), 1.0))
    # skip tips that would stack on an existing node (stalled tips)
    reps = nb.delete(reps, nb.cmp("LESS_THAN", nb.proximity(
        V, nb.attr("lv_n", "FLOAT_VECTOR")), nb.math("MULTIPLY", D, 0.2)))

    # one 2-vertex segment per new node, from parent to new position
    line = nb.n("GeometryNodeMeshLine",
                {"Count": 2, "Offset": (1.0, 0.0, 0.0)}, mode="OFFSET")
    segs = nb.n("GeometryNodeInstanceOnPoints",
                {"Points": reps, "Instance": line})
    segs = nb.n("GeometryNodeRealizeInstances", {"Geometry": segs})
    is_start = nb.math("SUBTRACT", 1.0, nb.math("MODULO", index, 2.0))
    segs = nb.n("GeometryNodeSetPosition",
                {"Geometry": segs, "Position": nb.mixv(
                    is_start, nb.attr("lv_n", "FLOAT_VECTOR"),
                    nb.attr("lv_t", "FLOAT_VECTOR"))})
    segs = nb.store(segs, "age", nb.math(
        "ADD", nb.math("MULTIPLY", is_start, nb.attr("lv_a")),
        nb.math("MULTIPLY", nb.math("SUBTRACT", 1.0, is_start), step1)))
    segs = nb.store(segs, "root", nb.math("MULTIPLY", is_start,
                                          nb.attr("lv_r")))
    # weld each segment's start onto its parent node
    V2 = nb.n("GeometryNodeMergeByDistance",
              {"Geometry": nb.join(V, segs),
               "Distance": nb.math("MULTIPLY", D, 0.01)})

    # kill sources reached by veins; drop dormant ones veins already cover
    A_keep = nb.delete(A, nb.cmp("LESS_THAN", nb.proximity(V2, pos),
                                 G("Kill Distance")))
    I_keep = nb.delete(I, nb.cmp("LESS_THAN", nb.proximity(V2, pos),
                                 nb.math("MAXIMUM", G("Kill Distance"),
                                         G("Vein Birth Distance"))))
    nb.link(V2, _find(rout.inputs, "Geometry"))
    nb.link(nb.join(A_keep, I_keep), _find(rout.inputs, "Sources"))
    nb.link(nb.math("ADD", step, 1.0), _find(rout.inputs, "Step"))

    veins = _find(rout.outputs, "Geometry")
    for name in ("lv_t", "lv_n", "lv_a", "lv_r", "lv_entry"):
        veins = nb.out(nb.n("GeometryNodeRemoveAttribute",
                            {"Geometry": veins, "Name": name}))
    nb.link(veins, _find(go.inputs, "Veins"))
    nb.link(_find(rout.outputs, "Sources"), _find(go.inputs, "Sources"))


def build_grow_group():
    t = _new_tree("Leaf Venation Grow")
    _sock(t, "Outline", "Geometry", desc="Closed leaf outline curve on the XY plane")
    for name, st, d, lo, hi, desc in GROW_INPUTS:
        _sock(t, name, st, default=d, lo=lo, hi=hi, desc=desc)
    _sock(t, "Veins", "Geometry", "OUTPUT")
    _sock(t, "Sources", "Geometry", "OUTPUT")
    gi, go = _io(t)
    nb = NB(t)
    G = lambda k: nb.out(gi, k)
    pos = nb.out(nb.n("GeometryNodeInputPosition"))
    index = nb.out(nb.n("GeometryNodeInputIndex"))

    D = G("Segment Length")
    growth = G("Growth")

    # -- auxin source field over the full-size leaf (Poisson disk) ----------
    blade = nb.n("GeometryNodeFillCurve", {"Curve": G("Outline")})
    sources = nb.out(nb.n("GeometryNodeDistributePointsOnFaces",
                          {"Mesh": blade, "Distance Min": G("Source Spacing"),
                           "Density Max": G("Source Density"),
                           "Seed": G("Random Seed")},
                          distribute_method="POISSON"), "Points")

    # -- entry scale: the leaf size at which the growing margin passes each
    #    source (paper Sec. 3.3). A ray is cast back from far outside toward
    #    the growth centre, so the first hit is the farthest margin crossing.
    wall = nb.n("GeometryNodeCurveToMesh", {"Curve": G("Outline")})
    wall = nb.n("GeometryNodeTransform", {"Geometry": wall,
                                          "Translation": (0.0, 0.0, -1.0)})
    wall = nb.n("GeometryNodeExtrudeMesh",
                {"Mesh": wall, "Offset": nb.vec(0.0, 0.0, 2.0)}, mode="EDGES")
    bbox = nb.n("GeometryNodeBoundBox", {"Geometry": G("Outline")})
    big = nb.math("ADD", nb.math("MULTIPLY", nb.vmath(
        "DISTANCE", nb.out(bbox, "Min"), nb.out(bbox, "Max")), 2.0), 1.0)
    p_xyz = nb.n("ShaderNodeSeparateXYZ", {"Vector": pos})
    b_xyz = nb.n("ShaderNodeSeparateXYZ", {"Vector": G("Base")})
    col_origin = nb.out(nb.n("ShaderNodeCombineXYZ",
                             {"X": nb.out(p_xyz, "X"), "Y": nb.out(b_xyz, "Y"),
                              "Z": nb.out(b_xyz, "Z")}))
    length_only = nb.cmp("EQUAL", growth, 3.0)
    origin = nb.mixv(length_only, G("Base"), col_origin)
    to_p = nb.vmath("SUBTRACT", pos, origin)
    dist_p = nb.vmath("LENGTH", to_p)
    dir_p = nb.vmath("NORMALIZE", to_p)
    far = nb.vmath("ADD", origin, nb.vmath("SCALE", dir_p, scale=big))
    ray = nb.n("GeometryNodeRaycast",
               {"Target Geometry": wall, "Source Position": far,
                "Ray Direction": nb.vmath("SCALE", dir_p, scale=-1.0),
                "Ray Length": nb.math("MULTIPLY", big, 2.0)})
    margin = nb.math("MAXIMUM", nb.math("SUBTRACT", big,
                                        nb.out(ray, "Hit Distance")), 1e-6)
    entry = nb.math("DIVIDE", dist_p, margin)
    # no hit -> never switches on
    entry = nb.math("ADD", nb.math("MULTIPLY", entry, nb.out(ray, "Is Hit")),
                    nb.math("MULTIPLY", 2.0, nb.math("SUBTRACT", 1.0,
                                                     nb.out(ray, "Is Hit"))))
    sources = nb.store(sources, "lv_entry", entry)

    # -- seed vein nodes ------------------------------------------------------
    count = G("Seed Count")
    half = nb.math("MULTIPLY", nb.math("SUBTRACT", count, 1.0),
                   nb.math("MULTIPLY", G("Seed Spacing"), 0.5))
    start = nb.vmath("SUBTRACT", G("Base"), nb.out(nb.n(
        "ShaderNodeCombineXYZ", {"X": half})))
    seeds = nb.n("GeometryNodeMeshLine",
                 {"Count": count, "Start Location": start,
                  "Offset": nb.out(nb.n("ShaderNodeCombineXYZ",
                                        {"X": G("Seed Spacing")}))},
                 mode="OFFSET")
    seeds = nb.delete(seeds, True, domain="EDGE", mode="EDGE_FACE")
    seeds = nb.store(seeds, "age", 0.0)
    seeds = nb.store(seeds, "root", 1.0)

    _grow_loop(t, nb, G, go, seeds, sources)
    return t


# ---------------------------------------------------------------------------
# Node group 2: vein widths (Murray's law), tubes and leaf blade
# ---------------------------------------------------------------------------

SKIN_INPUTS = [
    ("Age Limit", "Float", 100000.0, 0.0, None,
     "Show only veins grown up to this step. Keyframe it to animate growth"),
    ("Tip Radius", "Float", 0.15, 0.0, None, "Radius of the finest veinlets"),
    ("Murray Exponent", "Float", 2.5, 1.0, 4.0,
     "n in r_parent^n = sum r_child^n (2..3)"),
    ("Smooth Veins", "Bool", True, None, None, "Catmull-Rom smoothing of vein paths"),
    ("Vein Resolution", "Int", 6, 3, 64, "Sides of each vein tube"),
    ("Blade Thickness", "Float", 0.4, 0.0, None, "Thickness of the leaf blade"),
    ("Show Blade", "Bool", True, None, None, ""),
    ("Show Veins", "Bool", True, None, None, ""),
    ("Graph Only", "Bool", False, None, None,
     "Output the bare vein graph (edges with a 'radius' attribute)"),
    ("Blade Material", "Material", None, None, None, ""),
    ("Vein Material", "Material", None, None, None, ""),
]


def _vein_tubes(nb, G, offset=None):
    """Murray's-law radii on the vein graph, then tubes. Returns (graph, tubes)."""
    pos = nb.out(nb.n("GeometryNodeInputPosition"))
    index = nb.out(nb.n("GeometryNodeInputIndex"))
    V = nb.delete(G("Veins"), nb.cmp("GREATER_THAN", nb.attr("age"),
                                     G("Age Limit")))
    V = nb.store(V, "lv_vid", index, "INT")

    # Murray's law with equal tips: r^n is additive, so a node's radius is
    # tip_radius * (number of veinlet tips it feeds) ^ (1/n).
    root = nb.cmp("GREATER_THAN", nb.attr("root"), 0.5)
    nbrs = nb.out(nb.n("GeometryNodeInputMeshVertexNeighbors"), "Vertex Count")
    tips = nb.boolean("AND", nb.cmp("EQUAL", nbrs, 1.0),
                      nb.boolean("NOT", root))
    paths = nb.n("GeometryNodeInputShortestEdgePaths",
                 {"End Vertex": root, "Edge Cost": 1.0})
    curves = nb.out(nb.n("GeometryNodeEdgePathsToCurves",
                         {"Mesh": V, "Start Vertices": tips,
                          "Next Vertex Index": nb.out(paths, "Next Vertex Index")}))
    tally = nb.n("GeometryNodeAccumulateField",
                 {"Value": 1.0, "Group ID": nb.attr("lv_vid", "INT")},
                 data_type="FLOAT", domain="POINT")
    curves = nb.store(curves, "lv_cnt", nb.out(tally, "Total"))
    pts = nb.n("GeometryNodeCurveToMesh", {"Curve": curves})
    near = nb.out(nb.n("GeometryNodeSampleNearest",
                       {"Geometry": pts, "Sample Position": pos},
                       domain="POINT"))
    cnt = nb.sample_index(pts, nb.attr("lv_cnt"), near)
    # a vein mesh from the Python simulator brings its own tip counts
    # ('flow', from its growth tree), which keeps closed loops consistent
    flow = nb.n("GeometryNodeInputNamedAttribute", {"Name": "flow"},
                data_type="FLOAT")
    cnt = nb.switch(nb.out(flow, "Exists"), cnt, nb.out(flow, "Attribute"),
                    "FLOAT")
    cnt = nb.math("MAXIMUM", cnt, 1.0)
    radius = nb.math("MULTIPLY", G("Tip Radius"), nb.math(
        "POWER", cnt, nb.math("DIVIDE", 1.0, G("Murray Exponent"))))
    V = nb.store(V, "radius", radius)
    graph = nb.out(nb.n("GeometryNodeRemoveAttribute",
                        {"Geometry": V, "Name": "lv_vid"}))
    if offset is not None:   # e.g. lift veins along the surface normal
        graph = nb.out(nb.n("GeometryNodeSetPosition",
                            {"Geometry": graph, "Offset": offset}))

    # vein tubes
    crv = nb.out(nb.n("GeometryNodeMeshToCurve", {"Mesh": graph}))
    smooth = nb.n("GeometryNodeCurveSplineType", {"Curve": crv},
                  spline_type="CATMULL_ROM")
    smooth = nb.n("GeometryNodeSetSplineResolution",
                  {0: smooth, "Resolution": 3})
    crv = nb.switch(G("Smooth Veins"), crv, smooth)
    crv = nb.n("GeometryNodeSetCurveRadius",
               {"Curve": crv, "Radius": nb.attr("radius")})
    circle = nb.n("GeometryNodeCurvePrimitiveCircle",
                  {"Resolution": G("Vein Resolution"), "Radius": 1.0},
                  mode="RADIUS")
    tubes = nb.n("GeometryNodeCurveToMesh",
                 {"Curve": crv, "Profile Curve": circle, "Fill Caps": True})
    if any(s.name == "Scale" for s in tubes.inputs):
        # Blender 4.3+: Curve to Mesh no longer applies the radius by itself
        nb.link(nb.n("GeometryNodeInputRadius"), _find(tubes.inputs, "Scale"))
    tubes = nb.n("GeometryNodeSetMaterial",
                 {"Geometry": tubes, "Material": G("Vein Material")})
    return graph, tubes


def build_skin_group():
    t = _new_tree("Leaf Venation Skin Core")
    _sock(t, "Veins", "Geometry", desc="Vein mesh: vertices + edges, "
          "'root' and 'age' point attributes")
    _sock(t, "Outline", "Geometry", desc="Leaf outline curve")
    for name, st, d, lo, hi, desc in SKIN_INPUTS:
        _sock(t, name, st, default=d, lo=lo, hi=hi, desc=desc)
    _sock(t, "Geometry", "Geometry", "OUTPUT")
    gi, go = _io(t)
    nb = NB(t)
    G = lambda k: nb.out(gi, k)
    pos = nb.out(nb.n("GeometryNodeInputPosition"))
    index = nb.out(nb.n("GeometryNodeInputIndex"))

    graph, tubes = _vein_tubes(nb, G)
    # veins ride on the upper surface of the blade, so even fine ones show
    thick = G("Blade Thickness")
    tubes = nb.n("GeometryNodeTransform",
                 {"Geometry": tubes, "Translation": nb.vec(
                     0.0, 0.0, nb.math("MULTIPLY", thick, 0.5))})

    # leaf blade with a UV map that matches bake_texture()
    blade = nb.n("GeometryNodeFillCurve", {"Curve": G("Outline")})
    blade = nb.n("GeometryNodeExtrudeMesh",
                 {"Mesh": blade, "Offset": nb.vec(0.0, 0.0, 1.0),
                  "Offset Scale": thick}, mode="FACES")
    blade = nb.n("GeometryNodeTransform",
                 {"Geometry": blade, "Translation": nb.out(nb.n(
                     "ShaderNodeCombineXYZ",
                     {"Z": nb.math("MULTIPLY", thick, -0.5)}))})
    bbox = nb.n("GeometryNodeBoundBox", {"Geometry": G("Outline")})
    lo, hi = nb.out(bbox, "Min"), nb.out(bbox, "Max")
    size = nb.n("ShaderNodeSeparateXYZ", {"Vector": nb.vmath("SUBTRACT", hi, lo)})
    span = nb.math("MAXIMUM", nb.math("MAXIMUM", nb.out(size, "X"),
                                      nb.out(size, "Y")), 1e-6)
    centre = nb.vmath("SCALE", nb.vmath("ADD", lo, hi), scale=0.5)
    uv = nb.vmath("ADD", nb.vmath("SCALE", nb.vmath("SUBTRACT", pos, centre),
                                  scale=nb.math("DIVIDE", 1.0, span)),
                  (0.5, 0.5, 0.0))
    blade = nb.store(blade, "UVMap", uv, "FLOAT2", "CORNER")
    blade = nb.n("GeometryNodeSetMaterial",
                 {"Geometry": blade, "Material": G("Blade Material")})

    model = nb.join(nb.switch(G("Show Blade"), None, blade),
                    nb.switch(G("Show Veins"), None, tubes))
    nb.link(nb.switch(G("Graph Only"), model, graph), _find(go.inputs, "Geometry"))
    return t


def _expose(tree, gi, node, specs, skip=()):
    for name, st, d, lo, hi, desc in specs:
        if name in skip:
            continue
        _sock(tree, name, st, default=d, lo=lo, hi=hi, desc=desc)
        tree.links.new(_find(gi.outputs, name), _find(node.inputs, name))


def build_main_group(grow, skin):
    """'Leaf Venation': modifier for an outline curve object."""
    t = _new_tree("Leaf Venation")
    _sock(t, "Outline", "Geometry")
    _sock(t, "Geometry", "Geometry", "OUTPUT")
    gi, go = _io(t)
    g = t.nodes.new("GeometryNodeGroup")
    g.node_tree = grow
    s = t.nodes.new("GeometryNodeGroup")
    s.node_tree = skin
    g.location, s.location = (0, 0), (300, 0)
    t.links.new(_find(gi.outputs, "Outline"), _find(g.inputs, "Outline"))
    t.links.new(_find(gi.outputs, "Outline"), _find(s.inputs, "Outline"))
    _expose(t, gi, g, GROW_INPUTS)
    _expose(t, gi, s, SKIN_INPUTS)
    t.links.new(_find(g.outputs, "Veins"), _find(s.inputs, "Veins"))
    t.links.new(_find(s.outputs, "Geometry"), _find(go.inputs, "Geometry"))
    t.is_modifier = True
    return t


def build_skin_mesh_group(skin):
    """'Leaf Venation Skin': modifier for a vein mesh from the Python simulator."""
    t = _new_tree("Leaf Venation Skin")
    _sock(t, "Veins", "Geometry")
    _sock(t, "Outline Object", "Object", desc="The leaf outline curve object")
    _sock(t, "Geometry", "Geometry", "OUTPUT")
    gi, go = _io(t)
    info = t.nodes.new("GeometryNodeObjectInfo")
    info.transform_space = "RELATIVE"
    t.links.new(_find(gi.outputs, "Outline Object"), _find(info.inputs, "Object"))
    s = t.nodes.new("GeometryNodeGroup")
    s.node_tree = skin
    t.links.new(_find(gi.outputs, "Veins"), _find(s.inputs, "Veins"))
    t.links.new(_find(info.outputs, "Geometry"), _find(s.inputs, "Outline"))
    _expose(t, gi, s, SKIN_INPUTS)
    t.links.new(_find(s.outputs, "Geometry"), _find(go.inputs, "Geometry"))
    t.is_modifier = True
    return t


# ---------------------------------------------------------------------------
# Veins on any mesh object
# ---------------------------------------------------------------------------

SURFACE_GROW_INPUTS = [
    ("Start", "Vector", (0.0, 0.0, 0.0), None, None,
     "Where the first vein starts, in object space. It is snapped to the surface"),
    ("Mask", "String", "", None, None,
     "Optional vertex group: veins only grow where its weight is above 0.5"),
    ("Iterations", "Int", 250, 0, 5000, "Simulation steps"),
    ("Segment Length", "Float", 0.01, 0.00001, None,
     "D: length of a new vein segment"),
    ("Kill Distance", "Float", 0.03, 0.00001, None,
     "dk: a source dies when a vein comes this close"),
    ("Source Spacing", "Float", 0.03, 0.00001, None,
     "bs: minimum distance between auxin sources"),
    ("Vein Birth Distance", "Float", 0.03, 0.0, None,
     "bv: a source that switches on this close to a vein is dropped"),
    ("Source Density", "Float", 2000.0, 0.0, None,
     "Poisson candidates per unit area. Higher = more regular pattern"),
    ("Growth", "Int", 1, 0, 1,
     "0 all sources at once, 1 the vein field spreads out from Start"),
    ("Start Scale", "Float", 0.05, 0.001, 1.0, "Size of the field at step 0"),
    ("Growth Steps", "Int", 0, 0, 5000,
     "Steps until the field covers the object, 0 = 70% of Iterations"),
    ("Random Seed", "Int", 0, None, None, "Seed for the source field"),
]


def build_surface_grow_group():
    t = _new_tree("Leaf Venation Surface Grow")
    _sock(t, "Surface", "Geometry", desc="Mesh to grow the veins on")
    for name, st, d, lo, hi, desc in SURFACE_GROW_INPUTS:
        _sock(t, name, st, default=d, lo=lo, hi=hi, desc=desc)
    _sock(t, "Veins", "Geometry", "OUTPUT")
    _sock(t, "Sources", "Geometry", "OUTPUT")
    gi, go = _io(t)
    nb = NB(t)
    G = lambda k: nb.out(gi, k)
    pos = nb.out(nb.n("GeometryNodeInputPosition"))
    surf = nb.out(nb.n("GeometryNodeRealizeInstances", {"Geometry": G("Surface")}))

    def snap(p):
        node = nb.n("GeometryNodeProximity", target_element="FACES")
        nb.link(surf, node.inputs[0])
        nb.link(p, _find(node.inputs, "Source Position"))
        return nb.out(node, "Position")

    # sources on the (masked) surface
    mask = nb.n("GeometryNodeInputNamedAttribute", {"Name": G("Mask")},
                data_type="FLOAT")
    sel = nb.boolean("OR", nb.boolean("NOT", nb.out(mask, "Exists")),
                     nb.cmp("GREATER_THAN", nb.out(mask, "Attribute"), 0.5))
    sources = nb.out(nb.n("GeometryNodeDistributePointsOnFaces",
                          {"Mesh": surf, "Selection": sel,
                           "Distance Min": G("Source Spacing"),
                           "Density Max": G("Source Density"),
                           "Seed": G("Random Seed")},
                          distribute_method="POISSON"), "Points")
    # the field spreads out from Start: a source switches on when the growing
    # radius (a fraction of the farthest source distance) reaches it
    start = snap(G("Start"))
    dist = nb.vmath("DISTANCE", pos, start)
    far = nb.n("GeometryNodeAttributeStatistic",
               {"Geometry": sources, "Attribute": dist},
               data_type="FLOAT", domain="POINT")
    entry = nb.math("DIVIDE", dist, nb.math("MAXIMUM", nb.out(far, "Max"), 1e-9))
    sources = nb.store(sources, "lv_entry", entry)

    seeds = nb.n("GeometryNodeMeshLine", {"Count": 1, "Start Location": start},
                 mode="OFFSET")
    seeds = nb.store(seeds, "age", 0.0)
    seeds = nb.store(seeds, "root", 1.0)
    _grow_loop(t, nb, G, go, seeds, sources, snap=snap)
    return t


SURFACE_SKIN_INPUTS = [
    ("Age Limit", "Float", 100000.0, 0.0, None,
     "Show only veins grown up to this step. Keyframe it to animate growth"),
    ("Tip Radius", "Float", 0.0015, 0.0, None, "Radius of the finest veinlets"),
    ("Murray Exponent", "Float", 2.5, 1.0, 4.0,
     "n in r_parent^n = sum r_child^n (2..3)"),
    ("Smooth Veins", "Bool", True, None, None, "Catmull-Rom smoothing of vein paths"),
    ("Vein Resolution", "Int", 6, 3, 64, "Sides of each vein tube"),
    ("Vein Lift", "Float", 0.5, -1.0, 1.0,
     "How far the veins stick out: 1 sits on the surface, 0 half sunk in, "
     "negative sinks them (useful as a boolean cutter)"),
    ("Show Object", "Bool", True, None, None, "Keep the original mesh"),
    ("Graph Only", "Bool", False, None, None,
     "Output the bare vein graph (edges with a 'radius' attribute)"),
    ("Vein Material", "Material", None, None, None, ""),
]


def build_surface_group(grow):
    """'Leaf Venation Surface': modifier for any mesh object."""
    t = _new_tree("Leaf Venation Surface")
    _sock(t, "Geometry", "Geometry")
    _sock(t, "Geometry", "Geometry", "OUTPUT")
    gi, go = _io(t)
    g = t.nodes.new("GeometryNodeGroup")
    g.node_tree = grow
    t.links.new(gi.outputs[0], _find(g.inputs, "Surface"))
    _expose(t, gi, g, SURFACE_GROW_INPUTS)
    for name, st, d, lo, hi, desc in SURFACE_SKIN_INPUTS:
        _sock(t, name, st, default=d, lo=lo, hi=hi, desc=desc)
    nb = NB(t)
    G = lambda k: nb.out(gi, k)
    surf = nb.out(nb.n("GeometryNodeRealizeInstances", {"Geometry": gi.outputs[0]}))
    # lift each vein node along the surface normal by a share of its radius
    normal = nb.n("GeometryNodeSampleNearestSurface",
                  {"Mesh": surf, "Value": nb.out(nb.n("GeometryNodeInputNormal")),
                   "Sample Position": nb.out(nb.n("GeometryNodeInputPosition"))},
                  data_type="FLOAT_VECTOR")
    offset = nb.vmath("SCALE", nb.vmath("NORMALIZE", nb.out(normal, "Value")),
                      scale=nb.math("MULTIPLY", nb.attr("radius"), G("Vein Lift")))
    V = nb.out(g, "Veins")
    G2 = lambda k: V if k == "Veins" else G(k)
    graph, tubes = _vein_tubes(nb, G2, offset=offset)
    model = nb.join(nb.switch(G("Show Object"), None, gi.outputs[0]), tubes)
    nb.link(nb.switch(G("Graph Only"), model, graph), go.inputs[0])
    t.is_modifier = True
    return t


GROUP_NAMES = ("Leaf Venation", "Leaf Venation Skin", "Leaf Venation Surface")


def ensure_node_groups():
    """Build the node groups only if this file does not have them yet."""
    if not all(n in bpy.data.node_groups for n in GROUP_NAMES):
        build_node_groups()
    return [bpy.data.node_groups[n] for n in GROUP_NAMES]


def build_node_groups():
    grow = build_grow_group()
    skin = build_skin_group()
    build_surface_group(build_surface_grow_group())
    return build_main_group(grow, skin), build_skin_mesh_group(skin)


# ---------------------------------------------------------------------------
# Outlines, materials, presets
# ---------------------------------------------------------------------------

def _tri_wave(t):
    f = t - math.floor(t)
    return 1.0 - abs(2.0 * f - 1.0)


def leaf_outline(length=100.0, width=55.0, shape=0.4, tip=1.2, teeth=0,
                 tooth_amp=2.5, teeth2=0, tooth2_amp=0.8, samples=300):
    """Same outline as leaf_outline_ghpython.py: base (0,0), tip (0,length)."""
    right = []
    for i in range(samples + 1):
        u = i / float(samples)
        k = math.log(0.5) / math.log(max(1e-3, min(0.999, shape)))
        w = math.sin(math.pi * (u ** k)) ** 0.8
        w *= (1.0 - u) ** (tip - 1.0) if tip > 1.0 and u < 1.0 else 1.0
        hw = 0.5 * width * w
        if teeth > 0 and 0.05 < u < 0.97:
            tooth = tooth_amp * _tri_wave(u * teeth)
            if teeth2 > 0:
                tooth += tooth2_amp * _tri_wave(u * teeth * teeth2)
            hw += math.sin(math.pi * u) * tooth
        right.append((hw, u * length))
    left = [(-x, y) for x, y in reversed(right[1:-1])]
    return right + left


def fan_outline(radius=70.0, angle=120.0, samples=120):
    """Ginkgo-like fan: apex at the origin, arc above it."""
    a0 = math.radians(90 - angle / 2.0)
    a1 = math.radians(90 + angle / 2.0)
    arc = [(radius * math.cos(a0 + (a1 - a0) * i / samples),
            radius * math.sin(a0 + (a1 - a0) * i / samples))
           for i in range(samples + 1)]
    return [(0.0, 0.0)] + arc


def strip_outline(width=24.0, length=120.0):
    """Grass blade: flat-bottomed strip with a pointed tip."""
    h = width / 2.0
    pts = [(-h, 0.0), (h, 0.0)]
    pts += [(h, y) for y in [length * 0.85 * i / 20 for i in range(1, 21)]]
    pts += [(h * (1 - i / 10.0), length * 0.85 + length * 0.15 * i / 10.0)
            for i in range(1, 10)]
    pts += [(0.0, length)]
    pts += [(-x, y) for x, y in reversed(pts[2:-1])]
    return pts


def make_outline(name, points=None, kind="ovate", **kw):
    """Closed poly curve object on the XY plane."""
    if points is None:
        points = {"ovate": leaf_outline, "fan": fan_outline,
                  "strip": strip_outline}[kind](**kw)
    cu = bpy.data.curves.new(name, "CURVE")
    cu.dimensions = "2D"
    cu.fill_mode = "NONE"
    sp = cu.splines.new("POLY")
    sp.points.add(len(points) - 1)
    for p, (x, y) in zip(sp.points, points):
        p.co = (x, y, 0.0, 1.0)
    sp.use_cyclic_u = True
    obj = bpy.data.objects.new(name, cu)
    (bpy.context.collection or bpy.context.scene.collection).objects.link(obj)
    return obj


def _material(name, color, rough=0.5, sss=0.0):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = rough
        for key in ("Subsurface Weight", "Subsurface"):
            if key in bsdf.inputs:
                bsdf.inputs[key].default_value = sss
                break
    mat.diffuse_color = color
    return mat


def leaf_materials(suffix=""):
    blade = _material("Leaf Blade" + suffix, (0.10, 0.33, 0.05, 1.0), 0.45, 0.1)
    vein = _material("Leaf Vein" + suffix, (0.55, 0.65, 0.25, 1.0), 0.4)
    return blade, vein


# Parameters from GRASSHOPPER_GUIDE.md. Keys follow the node inputs.
PRESETS = {
    1: dict(title="Open dicot, marginal growth", outline=("ovate", {}),
            grow={"Growth": 1, "Segment Length": 1.0, "Kill Distance": 4.0,
                  "Source Spacing": 4.0, "Vein Birth Distance": 4.0,
                  "Iterations": 220, "Start Scale": 0.1},
            darts=60, closed=False),
    2: dict(title="Open, dense, smooth secondaries", outline=("ovate", {}),
            grow={"Growth": 0, "Segment Length": 0.8, "Kill Distance": 1.5,
                  "Source Spacing": 2.5, "Vein Birth Distance": 2.5,
                  "Iterations": 250},
            darts=150, closed=False),
    3: dict(title="Closed, toothed leaf",
            outline=("ovate", {"teeth": 12, "tooth_amp": 3.5}),
            grow={"Growth": 1, "Segment Length": 1.0, "Kill Distance": 1.5,
                  "Source Spacing": 4.0, "Vein Birth Distance": 4.0,
                  "Iterations": 250, "Start Scale": 0.1},
            darts=60, closed=True),
    4: dict(title="Reticulate, isogonic growth", outline=("ovate", {}),
            grow={"Growth": 2, "Segment Length": 0.8, "Kill Distance": 1.0,
                  "Source Spacing": 3.0, "Vein Birth Distance": 3.0,
                  "Iterations": 260, "Start Scale": 0.2},
            darts=40, closed=True),
    5: dict(title="Ginkgo fan, slow marginal growth", outline=("fan", {}),
            grow={"Growth": 1, "Segment Length": 1.0, "Kill Distance": 3.0,
                  "Source Spacing": 3.0, "Vein Birth Distance": 3.0,
                  "Iterations": 420, "Start Scale": 0.05, "Growth Steps": 400},
            darts=40, closed=False),
    6: dict(title="Grass, parallel", outline=("strip", {}),
            grow={"Growth": 3, "Segment Length": 0.5, "Kill Distance": 2.0,
                  "Source Spacing": 1.0, "Vein Birth Distance": 2.0,
                  "Iterations": 300, "Start Scale": 0.02, "Growth Steps": 150,
                  "Seed Count": 6, "Seed Spacing": 4.0},
            skin={"Tip Radius": 0.08},
            darts=500, closed=False),
}


def _set_inputs(mod, values):
    items = {i.name: i.identifier for i in mod.node_group.interface.items_tree
             if getattr(i, "in_out", None) == "INPUT"}
    for k, v in values.items():
        mod[items[k]] = v
    mod.node_group.interface_update(bpy.context)


def add_leaf_nodes(preset=1, name=None, location=(0.0, 0.0, 0.0), scale=0.01):
    """Geometry Nodes leaf: outline curve + 'Leaf Venation' modifier."""
    P = PRESETS[preset]
    if P["closed"]:
        print("Preset %d is a closed (looped) pattern; Geometry Nodes grows "
              "the open version. Use add_leaf_python(%d) for loops." % (preset, preset))
    group = ensure_node_groups()[0]
    kind, kw = P["outline"]
    obj = make_outline(name or "Leaf GN %d" % preset, kind=kind, **kw)
    obj.location = location
    obj.scale = (scale,) * 3
    mod = obj.modifiers.new("Leaf Venation", "NODES")
    mod.node_group = group
    blade, vein = leaf_materials()
    values = dict(P["grow"])
    values.update(P.get("skin", {}))
    values["Blade Material"] = blade
    values["Vein Material"] = vein
    _set_inputs(mod, values)
    return obj


class AgedVenation(Venation):
    """Venation that records the step at which each node was created."""

    def _add_node(self, x, y, parent):
        i = Venation._add_node(self, x, y, parent)
        ages = self.__dict__.setdefault("ages", [])
        ages.append(float(getattr(self, "_step_no", 0)))
        return i

    def step(self):
        self._step_no = getattr(self, "_step_no", 0) + 1
        return Venation.step(self)


def add_leaf_python(preset=1, name=None, location=(0.0, 0.0, 0.0), scale=0.01,
                    seed=1):
    """Python-simulated leaf (open or closed): vein mesh + 'Leaf Venation Skin'."""
    P = PRESETS[preset]
    g = P["grow"]
    kind, kw = P["outline"]
    outline = make_outline((name or "Leaf PY %d" % preset) + " outline",
                           kind=kind, **kw)
    poly = [tuple(p.co[:2]) for p in outline.data.splines[0].points]
    n_seeds = g.get("Seed Count", 1)
    sp = g.get("Seed Spacing", 4.0)
    seeds = [((i - (n_seeds - 1) / 2.0) * sp, 0.0) for i in range(n_seeds)]
    sim = AgedVenation(
        poly, seeds, base=(0.0, 0.0), D=g["Segment Length"],
        kill=g["Kill Distance"], birth_s=g["Source Spacing"],
        birth_v=g["Vein Birth Distance"], darts=P["darts"],
        growth=g["Growth"], start_scale=g.get("Start Scale", 0.15),
        iterations=g["Iterations"], closed=P["closed"], seed=seed,
        grow_steps=g.get("Growth Steps", 0))
    sim.run()
    me = bpy.data.meshes.new(name or "Leaf PY %d" % preset)
    me.from_pydata([(x, y, 0.0) for x, y in sim.node_xy], sim.edges(), [])
    age = me.attributes.new("age", "FLOAT", "POINT")
    age.data.foreach_set("value", sim.ages)
    flow = me.attributes.new("flow", "FLOAT", "POINT")
    flow.data.foreach_set("value", sim.radii(1.0, 1.0))   # tips fed per node
    root = me.attributes.new("root", "FLOAT", "POINT")
    root.data.foreach_set("value", [1.0 if p < 0 else 0.0 for p in sim.parent])
    obj = bpy.data.objects.new(me.name, me)
    (bpy.context.collection or bpy.context.scene.collection).objects.link(obj)
    obj.location = location
    obj.scale = (scale,) * 3
    outline.parent = obj
    outline.hide_render = True
    outline.hide_set(True)
    group = ensure_node_groups()[1]
    mod = obj.modifiers.new("Leaf Venation Skin", "NODES")
    mod.node_group = group
    blade, vein = leaf_materials()
    values = dict(P.get("skin", {}))
    values.update({"Outline Object": outline, "Blade Material": blade,
                   "Vein Material": vein})
    _set_inputs(mod, values)
    return obj


def add_venation_to_object(obj, start=None, detail=1.0, seed=0):
    """Put a 'Leaf Venation Surface' modifier on a mesh object, with distances
    scaled to its size. start: point in object space (default: lowest point)."""
    group = ensure_node_groups()[2]
    me = obj.data
    if len(me.vertices) == 0:
        raise ValueError("The mesh has no vertices")
    xs = [v.co for v in me.vertices]
    lo = [min(c[i] for c in xs) for i in range(3)]
    hi = [max(c[i] for c in xs) for i in range(3)]
    size = max(hi[i] - lo[i] for i in range(3)) or 1.0
    if start is None:
        start = min(xs, key=lambda c: c[2])
    D = size / 100.0 / max(detail, 1e-3)
    mod = obj.modifiers.new("Leaf Venation", "NODES")
    mod.node_group = group
    vein = _material("Leaf Vein", (0.55, 0.65, 0.25, 1.0), 0.4)
    _set_inputs(mod, {
        "Start": tuple(start), "Segment Length": D, "Kill Distance": 3 * D,
        "Source Spacing": 3 * D, "Vein Birth Distance": 3 * D,
        "Source Density": 2.0 / (9 * D * D), "Tip Radius": 0.15 * D,
        "Iterations": int(250 * max(detail, 1.0)), "Random Seed": seed,
        "Vein Material": vein})
    return mod


# ---------------------------------------------------------------------------
# Texture: rasterise the vein graph to a PNG (no GPU or render needed)
# ---------------------------------------------------------------------------

def _graph_and_outline(obj):
    """Vein graph (verts, edges, radii) and outline polygon of a leaf object."""
    mod = next(m for m in obj.modifiers if m.type == "NODES")
    ids = {i.name: i.identifier for i in mod.node_group.interface.items_tree
           if getattr(i, "in_out", None) == "INPUT"}
    old = mod[ids["Graph Only"]]
    mod[ids["Graph Only"]] = True
    obj.update_tag()
    dg = bpy.context.evaluated_depsgraph_get()
    dg.update()
    ev = obj.evaluated_get(dg)
    me = ev.to_mesh()
    verts = [tuple(v.co[:2]) for v in me.vertices]
    edges = [tuple(e.vertices) for e in me.edges]
    rad = [d.value for d in me.attributes["radius"].data]
    ev.to_mesh_clear()
    mod[ids["Graph Only"]] = old
    obj.update_tag()
    if "Outline Object" in ids:
        oc = mod[ids["Outline Object"]]
    else:
        oc = obj
    poly = [tuple(p.co[:2]) for p in oc.data.splines[0].points]
    return verts, edges, rad, poly


def bake_texture(obj, path, size=2048, hook_material=True):
    """White veins on a grey leaf over black, framed like the blade UVMap."""
    import numpy as np
    verts, edges, rad, poly = _graph_and_outline(obj)
    P = np.array(poly, dtype=np.float64)
    lo, hi = P.min(0), P.max(0)
    span = max(hi[0] - lo[0], hi[1] - lo[1])
    centre = (lo + hi) / 2.0
    k = size / span

    def to_px(xy):
        return (np.asarray(xy) - centre) * k + size / 2.0

    # leaf fill (even-odd scanline)
    Q = to_px(P)
    leaf = np.zeros((size, size), dtype=np.float32)
    x0, y0 = Q[:, 0], Q[:, 1]
    x1, y1 = np.roll(x0, -1), np.roll(y0, -1)
    xs = np.arange(size) + 0.5
    for row in range(size):
        y = row + 0.5
        m = (y0 > y) != (y1 > y)
        if not m.any():
            continue
        cx = np.sort(x0[m] + (y - y0[m]) * (x1[m] - x0[m]) / (y1[m] - y0[m]))
        for a, b in zip(cx[0::2], cx[1::2]):
            leaf[row, (xs >= a) & (xs < b)] = 1.0
    # veins: anti-aliased capsules
    V = to_px(verts) if verts else np.zeros((0, 2))
    R = np.asarray(rad) * k
    vein = np.zeros((size, size), dtype=np.float32)
    for a, b in edges:
        pa, pb = V[a], V[b]
        r = max(0.7, R[b])
        xa, xb = int(max(0, min(pa[0], pb[0]) - r - 2)), int(min(size, max(pa[0], pb[0]) + r + 2))
        ya, yb = int(max(0, min(pa[1], pb[1]) - r - 2)), int(min(size, max(pa[1], pb[1]) + r + 2))
        if xa >= xb or ya >= yb:
            continue
        gx, gy = np.meshgrid(np.arange(xa, xb) + 0.5, np.arange(ya, yb) + 0.5)
        d = pb - pa
        L2 = max(float(d @ d), 1e-12)
        t = np.clip(((gx - pa[0]) * d[0] + (gy - pa[1]) * d[1]) / L2, 0, 1)
        dist = np.hypot(gx - pa[0] - t * d[0], gy - pa[1] - t * d[1])
        np.maximum(vein[ya:yb, xa:xb], np.clip(r + 0.5 - dist, 0, 1),
                   out=vein[ya:yb, xa:xb])
    val = np.maximum(leaf * 0.27, vein)
    rgba = np.ones((size, size, 4), dtype=np.float32)
    rgba[..., 0] = rgba[..., 1] = rgba[..., 2] = val
    name = bpy.path.basename(path)
    img = bpy.data.images.get(name)
    if img is not None:
        bpy.data.images.remove(img)
    img = bpy.data.images.new(name, size, size, alpha=False)
    img.pixels.foreach_set(rgba.ravel())   # row 0 is the bottom in Blender
    img.filepath_raw = path
    img.file_format = "PNG"
    img.save()
    if hook_material:
        _hook_texture(obj, img)
    return img


def _hook_texture(obj, img):
    """Blade material that mixes a vein colour and bump from the texture."""
    mod = next(m for m in obj.modifiers if m.type == "NODES")
    ids = {i.name: i.identifier for i in mod.node_group.interface.items_tree
           if getattr(i, "in_out", None) == "INPUT"}
    mat = _material("Leaf Blade Textured " + obj.name, (0.1, 0.33, 0.05, 1), 0.45, 0.1)
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    uv = nt.nodes.new("ShaderNodeUVMap")
    uv.uv_map = "UVMap"
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.image.colorspace_settings.name = "Non-Color"
    nt.links.new(uv.outputs["UV"], tex.inputs["Vector"])
    ramp = nt.nodes.new("ShaderNodeMapRange")   # 0.27 leaf .. 1 vein -> 0..1
    ramp.inputs["From Min"].default_value = 0.27
    nt.links.new(tex.outputs["Color"], ramp.inputs["Value"])
    mix = nt.nodes.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    nt.links.new(ramp.outputs["Result"], mix.inputs["Factor"])
    mix.inputs["A"].default_value = (0.10, 0.33, 0.05, 1.0)
    mix.inputs["B"].default_value = (0.55, 0.65, 0.25, 1.0)
    nt.links.new(_find(mix.outputs, "Result"), bsdf.inputs["Base Color"])
    bump = nt.nodes.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = 0.4
    nt.links.new(ramp.outputs["Result"], bump.inputs["Height"])
    nt.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    mod[ids["Blade Material"]] = mat
    obj.update_tag()
    return mat


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

def build_demo(nodes_presets=(1, 2, 5, 6), python_presets=(3, 4)):
    """Six leaves in a row: Geometry Nodes for open presets, Python for closed."""
    build_node_groups()
    objs = []
    x = 0.0
    for p in sorted(set(nodes_presets) | set(python_presets)):
        loc = (x, 0.0, 0.0)
        if p in nodes_presets:
            objs.append(add_leaf_nodes(p, location=loc))
        else:
            objs.append(add_leaf_python(p, location=loc))
        x += 1.6
    return objs


