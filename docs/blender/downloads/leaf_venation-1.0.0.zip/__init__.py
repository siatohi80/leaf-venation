# SPDX-License-Identifier: MIT
# Leaf Venation for Blender: space colonization leaf veins (Runions et al. 2005)
# as Geometry Nodes, on flat leaves or on any mesh.

import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       IntProperty, StringProperty)

from . import core

PRESET_ITEMS = [(str(k), "%d  %s" % (k, v["title"]), v["title"])
                for k, v in sorted(core.PRESETS.items())]


def _lv_modifier(obj):
    if obj is None:
        return None
    for m in obj.modifiers:
        if m.type == "NODES" and m.node_group and m.node_group.name.startswith(
                "Leaf Venation"):
            return m
    return None


def _input_ids(mod):
    return {i.name: i.identifier for i in mod.node_group.interface.items_tree
            if getattr(i, "in_out", None) == "INPUT"}


class LEAFVEN_OT_add_leaf(bpy.types.Operator):
    """Add a leaf with grown veins at the 3D cursor"""
    bl_idname = "leaf_venation.add_leaf"
    bl_label = "Add Leaf"
    bl_options = {"REGISTER", "UNDO"}

    preset: EnumProperty(name="Preset", items=PRESET_ITEMS, default="1")
    size: FloatProperty(name="Size", default=1.0, min=0.001, unit="LENGTH",
                        description="Approximate leaf length")
    looped: BoolProperty(
        name="Looped Veins (Python)", default=False,
        description="Grow with the Python simulator, which also makes closed "
        "loops. The result is a fixed vein mesh; presets 3 and 4 always use it")
    seed: IntProperty(name="Random Seed", default=1)

    def execute(self, context):
        p = int(self.preset)
        loc = tuple(context.scene.cursor.location)
        scale = self.size / 100.0
        for o in context.selected_objects:
            o.select_set(False)
        if self.looped or core.PRESETS[p]["closed"]:
            obj = core.add_leaf_python(p, location=loc, scale=scale, seed=self.seed)
        else:
            obj = core.add_leaf_nodes(p, location=loc, scale=scale)
            mod = _lv_modifier(obj)
            mod[_input_ids(mod)["Random Seed"]] = self.seed
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {"FINISHED"}


class LEAFVEN_OT_apply_to_object(bpy.types.Operator):
    """Grow veins over the selected mesh objects (Geometry Nodes modifier)"""
    bl_idname = "leaf_venation.apply_to_object"
    bl_label = "Add Veins to Selected"
    bl_options = {"REGISTER", "UNDO"}

    start: EnumProperty(name="Start", items=[
        ("CURSOR", "3D Cursor", "Veins start at the surface point nearest the 3D cursor"),
        ("LOWEST", "Lowest Point", "Veins start at the object's lowest vertex"),
    ], default="CURSOR")
    detail: FloatProperty(name="Detail", default=1.0, min=0.2, max=5.0,
                          description="Higher gives finer, denser veins (slower)")
    seed: IntProperty(name="Random Seed", default=0)

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" for o in context.selected_objects)

    def execute(self, context):
        done = 0
        for obj in context.selected_objects:
            if obj.type != "MESH":
                continue
            start = None
            if self.start == "CURSOR":
                start = obj.matrix_world.inverted() @ context.scene.cursor.location
            try:
                core.add_venation_to_object(obj, start=start, detail=self.detail,
                                            seed=self.seed)
                done += 1
            except ValueError as e:
                self.report({"WARNING"}, "%s: %s" % (obj.name, e))
        if not done:
            return {"CANCELLED"}
        self.report({"INFO"}, "Added veins to %d object(s). Settings are in "
                    "the Modifier panel" % done)
        return {"FINISHED"}


class LEAFVEN_OT_start_from_cursor(bpy.types.Operator):
    """Move the start of the veins to the 3D cursor"""
    bl_idname = "leaf_venation.start_from_cursor"
    bl_label = "Start at 3D Cursor"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        mod = _lv_modifier(context.object)
        return mod is not None and "Start" in _input_ids(mod)

    def execute(self, context):
        obj = context.object
        mod = _lv_modifier(obj)
        mod[_input_ids(mod)["Start"]] = tuple(
            obj.matrix_world.inverted() @ context.scene.cursor.location)
        obj.update_tag()
        return {"FINISHED"}


class LEAFVEN_OT_bake_texture(bpy.types.Operator):
    """Write a PNG vein texture for the active flat leaf and use it on its blade"""
    bl_idname = "leaf_venation.bake_texture"
    bl_label = "Bake Vein Texture"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(subtype="FILE_PATH")
    size: IntProperty(name="Size", default=2048, min=64, max=8192)
    filter_glob: StringProperty(default="*.png", options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        mod = _lv_modifier(context.object)
        return mod is not None and "Blade Material" in _input_ids(mod)

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = bpy.path.abspath("//") + bpy.path.clean_name(
                context.object.name) + "_veins.png"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        path = bpy.path.ensure_ext(bpy.path.abspath(self.filepath), ".png")
        core.bake_texture(context.object, path, self.size)
        self.report({"INFO"}, "Texture written to " + path)
        return {"FINISHED"}


class LEAFVEN_PT_panel(bpy.types.Panel):
    bl_label = "Leaf Venation"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Leaf"

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator_menu_enum(LEAFVEN_OT_add_leaf.bl_idname, "preset",
                               text="Add Leaf", icon="ADD")
        col.operator(LEAFVEN_OT_apply_to_object.bl_idname, icon="MOD_NOISE")
        mod = _lv_modifier(context.object)
        if mod is None:
            return
        box = self.layout.box()
        box.label(text=context.object.name, icon="OBJECT_DATA")
        ids = _input_ids(mod)
        for name in ("Random Seed", "Iterations", "Kill Distance",
                     "Tip Radius", "Age Limit"):
            if name in ids:
                box.prop(mod, '["%s"]' % ids[name], text=name)
        if "Start" in ids:
            box.operator(LEAFVEN_OT_start_from_cursor.bl_idname, icon="PIVOT_CURSOR")
        if "Blade Material" in ids:
            box.operator(LEAFVEN_OT_bake_texture.bl_idname, icon="TEXTURE")
        box.label(text="All settings: Modifier panel", icon="MODIFIER")


def _add_menu(self, context):
    self.layout.operator_menu_enum(LEAFVEN_OT_add_leaf.bl_idname, "preset",
                                   text="Leaf (Venation)", icon="OUTLINER_OB_CURVE")


CLASSES = (LEAFVEN_OT_add_leaf, LEAFVEN_OT_apply_to_object,
           LEAFVEN_OT_start_from_cursor, LEAFVEN_OT_bake_texture,
           LEAFVEN_PT_panel)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_add.append(_add_menu)


def unregister():
    bpy.types.VIEW3D_MT_add.remove(_add_menu)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
